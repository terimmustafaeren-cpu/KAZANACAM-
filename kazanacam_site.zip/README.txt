KAZANACAM™ demo site
Files:
- index.html : main page
- styles.css : styles
- script.js : interactive behaviors (demo data)
- assets/logo.svg : simple logo

How to use:
1. Download and unzip.
2. Open index.html in a browser (double-click). Works offline as a demo.
3. To publish: create a GitHub repository and upload these files, then enable GitHub Pages (branch: main, folder: root).

This is a demo. For production you'll want server hosting, database, and legal checks for content.
